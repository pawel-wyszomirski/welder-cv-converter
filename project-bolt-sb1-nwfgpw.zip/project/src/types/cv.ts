export interface WelderCV {
  personalData: {
    fullName: string;
    phone: string;
    email: string;
  };
  professionalProfile: string;
  weldingMethods: {
    method: string;
    experience: string;
  }[];
  professionalExperience: {
    period: string;
    details: string[];
  }[];
  certificates: {
    welding: string[];
    healthAndSafety: string[];
    transport: string[];
  };
  technicalSkills: string[];
  additionalInfo: {
    mobility: string;
    rotation: string;
    employmentForm: string;
    ownEquipment: string;
  };
  developmentDirection: string;
}