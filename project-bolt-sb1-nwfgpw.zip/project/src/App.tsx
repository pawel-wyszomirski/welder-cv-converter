import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileType, Loader2 } from 'lucide-react';
import FileProcessor from './components/FileProcessor';
import CVPreview from './components/CVPreview';
import type { WelderCV } from './types/cv';

function App() {
  const [file, setFile] = useState<File | null>(null);
  const [processing, setProcessing] = useState(false);
  const [cvData, setCVData] = useState<WelderCV | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onDrop = (acceptedFiles: File[]) => {
    setError(null);
    setCVData(null);
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    maxFiles: 1
  });

  const handleProcessed = (data: WelderCV) => {
    setCVData(data);
  };

  const handleError = (errorMessage: string) => {
    setError(errorMessage);
    setProcessing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            CV Spawacza - Konwerter
          </h1>
          <p className="text-lg text-gray-600">
            Przekonwertuj CV spawacza do standardowego formatu PDF
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-md">
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
                ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}
            >
              <input {...getInputProps()} />
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-4 text-lg text-gray-600">
                Przeciągnij i upuść plik CV lub kliknij aby wybrać
              </p>
              <p className="mt-2 text-sm text-gray-500">
                Obsługiwane formaty: PDF, DOC, DOCX, JPG
              </p>
            </div>

            {file && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <FileType className="h-6 w-6 text-blue-500 mr-2" />
                  <span className="text-sm font-medium text-gray-900">
                    {file.name}
                  </span>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            {processing && (
              <div className="mt-6 flex items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-blue-500 mr-2" />
                <span className="text-sm text-gray-600">Przetwarzanie CV...</span>
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-xl shadow-md overflow-auto max-h-[800px]">
            {cvData ? (
              <CVPreview data={cvData} />
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500 text-center">
                  Podgląd przetworzonego CV pojawi się tutaj
                </p>
              </div>
            )}
          </div>
        </div>

        {file && (
          <FileProcessor
            file={file}
            onProcessing={setProcessing}
            onProcessed={handleProcessed}
            onError={handleError}
          />
        )}
      </div>
    </div>
  );
}

export default App;