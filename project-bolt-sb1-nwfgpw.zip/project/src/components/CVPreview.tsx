import React, { useState } from 'react';
import { Check, X, Edit2, Camera } from 'lucide-react';
import { generatePDF } from '../services/pdfGenerator';
import type { WelderCV } from '../types/cv';

interface CVPreviewProps {
  data: WelderCV;
}

const CVPreview: React.FC<CVPreviewProps> = ({ data }) => {
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [editedContent, setEditedContent] = useState<any>(null);
  const [currentData, setCurrentData] = useState<WelderCV>(data);
  const [photo, setPhoto] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startEditing = (section: string, content: any) => {
    setEditingSection(section);
    setEditedContent(content);
  };

  const saveEditing = () => {
    setCurrentData(prev => ({
      ...prev,
      [editingSection!]: editedContent
    }));
    setEditingSection(null);
    setEditedContent(null);
  };

  const cancelEditing = () => {
    setEditingSection(null);
    setEditedContent(null);
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadPDF = async () => {
    try {
      setError(null);
      await generatePDF(currentData, photo);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Błąd podczas generowania PDF');
    }
  };

  const renderCertificates = (certificates: WelderCV['certificates']) => (
    <div className="space-y-4">
      <div>
        <h4 className="font-semibold mb-2">SPAWALNICZE:</h4>
        <ul className="list-disc pl-5">
          {certificates.welding.map((cert, idx) => (
            <li key={idx}>{cert}</li>
          ))}
        </ul>
      </div>
      <div>
        <h4 className="font-semibold mb-2">BHP:</h4>
        <ul className="list-disc pl-5">
          {certificates.healthAndSafety.map((cert, idx) => (
            <li key={idx}>{cert}</li>
          ))}
        </ul>
      </div>
      <div>
        <h4 className="font-semibold mb-2">TRANSPORT BLISKI:</h4>
        <ul className="list-disc pl-5">
          {certificates.transport.map((cert, idx) => (
            <li key={idx}>{cert}</li>
          ))}
        </ul>
      </div>
    </div>
  );

  const renderAdditionalInfo = (info: WelderCV['additionalInfo']) => (
    <div className="space-y-2">
      <p>MOBILNOŚĆ: {info.mobility}</p>
      <p>ROTACJA: {info.rotation}</p>
      <p>FORMA ZATRUDNIENIA: {info.employmentForm}</p>
      <p>WŁASNY SPRZĘT: {info.ownEquipment}</p>
    </div>
  );

  const renderEditableSection = (title: string, content: any, section: string) => {
    const isEditing = editingSection === section;

    const renderContent = () => {
      if (isEditing) {
        switch (section) {
          case 'personalData':
            return (
              <div className="space-y-2">
                <input
                  type="text"
                  value={editedContent.fullName}
                  onChange={(e) => setEditedContent({ ...editedContent, fullName: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Imię i nazwisko"
                />
                <input
                  type="text"
                  value={editedContent.phone}
                  onChange={(e) => setEditedContent({ ...editedContent, phone: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Telefon"
                />
                <input
                  type="email"
                  value={editedContent.email}
                  onChange={(e) => setEditedContent({ ...editedContent, email: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Email"
                />
              </div>
            );
          case 'professionalProfile':
            return (
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                className="w-full p-2 border rounded min-h-[100px]"
                placeholder="Profil zawodowy"
              />
            );
          case 'weldingMethods':
            return (
              <div className="space-y-4">
                {editedContent.map((method: any, index: number) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={method.method}
                      onChange={(e) => {
                        const newMethods = [...editedContent];
                        newMethods[index].method = e.target.value;
                        setEditedContent(newMethods);
                      }}
                      className="flex-1 p-2 border rounded"
                      placeholder="Metoda spawania"
                    />
                    <input
                      type="text"
                      value={method.experience}
                      onChange={(e) => {
                        const newMethods = [...editedContent];
                        newMethods[index].experience = e.target.value;
                        setEditedContent(newMethods);
                      }}
                      className="flex-1 p-2 border rounded"
                      placeholder="Doświadczenie"
                    />
                    <button
                      onClick={() => {
                        const newMethods = editedContent.filter((_: any, i: number) => i !== index);
                        setEditedContent(newMethods);
                      }}
                      className="p-2 text-red-600 hover:bg-red-50 rounded"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => setEditedContent([...editedContent, { method: '', experience: '' }])}
                  className="w-full p-2 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
                >
                  Dodaj metodę
                </button>
              </div>
            );
          case 'professionalExperience':
            return (
              <div className="space-y-4">
                {editedContent.map((exp: any, index: number) => (
                  <div key={index} className="space-y-2">
                    <input
                      type="text"
                      value={exp.period}
                      onChange={(e) => {
                        const newExp = [...editedContent];
                        newExp[index].period = e.target.value;
                        setEditedContent(newExp);
                      }}
                      className="w-full p-2 border rounded"
                      placeholder="Okres"
                    />
                    <textarea
                      value={exp.details.join('\n')}
                      onChange={(e) => {
                        const newExp = [...editedContent];
                        newExp[index].details = e.target.value.split('\n').filter(Boolean);
                        setEditedContent(newExp);
                      }}
                      className="w-full p-2 border rounded min-h-[100px]"
                      placeholder="Szczegóły (każdy w nowej linii)"
                    />
                    <button
                      onClick={() => {
                        const newExp = editedContent.filter((_: any, i: number) => i !== index);
                        setEditedContent(newExp);
                      }}
                      className="p-2 text-red-600 hover:bg-red-50 rounded"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => setEditedContent([...editedContent, { period: '', details: [] }])}
                  className="w-full p-2 bg-blue-50 text-blue-600 rounded hover:bg-blue-100"
                >
                  Dodaj doświadczenie
                </button>
              </div>
            );
          case 'certificates':
            return (
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">SPAWALNICZE:</h4>
                  <textarea
                    value={editedContent.welding.join('\n')}
                    onChange={(e) => setEditedContent({
                      ...editedContent,
                      welding: e.target.value.split('\n').filter(Boolean)
                    })}
                    className="w-full p-2 border rounded min-h-[100px]"
                    placeholder="Każdy certyfikat w nowej linii"
                  />
                </div>
                <div>
                  <h4 className="font-semibold mb-2">BHP:</h4>
                  <textarea
                    value={editedContent.healthAndSafety.join('\n')}
                    onChange={(e) => setEditedContent({
                      ...editedContent,
                      healthAndSafety: e.target.value.split('\n').filter(Boolean)
                    })}
                    className="w-full p-2 border rounded min-h-[100px]"
                    placeholder="Każdy certyfikat w nowej linii"
                  />
                </div>
                <div>
                  <h4 className="font-semibold mb-2">TRANSPORT BLISKI:</h4>
                  <textarea
                    value={editedContent.transport.join('\n')}
                    onChange={(e) => setEditedContent({
                      ...editedContent,
                      transport: e.target.value.split('\n').filter(Boolean)
                    })}
                    className="w-full p-2 border rounded min-h-[100px]"
                    placeholder="Każdy certyfikat w nowej linii"
                  />
                </div>
              </div>
            );
          case 'technicalSkills':
            return (
              <textarea
                value={editedContent.join('\n')}
                onChange={(e) => setEditedContent(e.target.value.split('\n').filter(Boolean))}
                className="w-full p-2 border rounded min-h-[100px]"
                placeholder="Każda umiejętność w nowej linii"
              />
            );
          case 'additionalInfo':
            return (
              <div className="space-y-2">
                <input
                  type="text"
                  value={editedContent.mobility}
                  onChange={(e) => setEditedContent({ ...editedContent, mobility: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Mobilność"
                />
                <input
                  type="text"
                  value={editedContent.rotation}
                  onChange={(e) => setEditedContent({ ...editedContent, rotation: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Rotacja"
                />
                <input
                  type="text"
                  value={editedContent.employmentForm}
                  onChange={(e) => setEditedContent({ ...editedContent, employmentForm: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Forma zatrudnienia"
                />
                <input
                  type="text"
                  value={editedContent.ownEquipment}
                  onChange={(e) => setEditedContent({ ...editedContent, ownEquipment: e.target.value })}
                  className="w-full p-2 border rounded"
                  placeholder="Własny sprzęt"
                />
              </div>
            );
          case 'developmentDirection':
            return (
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                className="w-full p-2 border rounded min-h-[100px]"
                placeholder="Kierunek rozwoju"
              />
            );
          default:
            return null;
        }
      } else {
        switch (section) {
          case 'personalData':
            return (
              <>
                <p>IMIĘ I NAZWISKO: {content.fullName}</p>
                <p>TEL: {content.phone}</p>
                <p>EMAIL: {content.email}</p>
              </>
            );
          case 'professionalProfile':
            return <p>{content}</p>;
          case 'weldingMethods':
            return (
              <div className="grid grid-cols-3 gap-4">
                {content.map((method: any, index: number) => (
                  <div key={index} className="text-center">
                    <div className="welding-method-circle mx-auto mb-2">
                      <span className="font-mono text-sm">{method.method}</span>
                    </div>
                    <p className="font-mono text-sm">{method.experience}</p>
                  </div>
                ))}
              </div>
            );
          case 'professionalExperience':
            return (
              <div className="space-y-4">
                {content.map((exp: any, index: number) => (
                  <div key={index}>
                    <p className="font-bold">{exp.period}</p>
                    <ul className="list-disc pl-5 mt-1">
                      {exp.details.map((detail: string, idx: number) => (
                        <li key={idx}>{detail}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            );
          case 'certificates':
            return renderCertificates(content);
          case 'technicalSkills':
            return (
              <ul className="list-disc pl-5">
                {content.map((skill: string, index: number) => (
                  <li key={index}>{skill}</li>
                ))}
              </ul>
            );
          case 'additionalInfo':
            return renderAdditionalInfo(content);
          case 'developmentDirection':
            return <p>{content}</p>;
          default:
            return null;
        }
      }
    };

    return (
      <section className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">{title}</h3>
          {isEditing ? (
            <div className="flex gap-2">
              <button
                onClick={saveEditing}
                className="p-1 text-green-600 hover:bg-green-50 rounded"
                title="Zapisz"
              >
                <Check className="w-5 h-5" />
              </button>
              <button
                onClick={cancelEditing}
                className="p-1 text-red-600 hover:bg-red-50 rounded"
                title="Anuluj"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => startEditing(section, content)}
              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
              title="Edytuj"
            >
              <Edit2 className="w-5 h-5" />
            </button>
          )}
        </div>
        <div className="border rounded-lg p-4">
          {renderContent()}
        </div>
      </section>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">CV SPAWACZA</h2>
        <div className="flex gap-4">
          <div>
            <input
              type="file"
              id="photo-upload"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <label
              htmlFor="photo-upload"
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg cursor-pointer hover:bg-gray-200"
            >
              <Camera className="w-5 h-5" />
              {photo ? 'Zmień zdjęcie' : 'Dodaj zdjęcie'}
            </label>
          </div>
          <button
            onClick={handleDownloadPDF}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Pobierz PDF
          </button>
        </div>
      </div>

      {photo && (
        <div className="flex justify-end">
          <img
            src={photo}
            alt="Zdjęcie CV"
            className="w-32 h-40 object-cover rounded-lg"
          />
        </div>
      )}

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg">
          {error}
        </div>
      )}

      {renderEditableSection('DANE OSOBOWE', currentData.personalData, 'personalData')}
      {renderEditableSection('PROFIL ZAWODOWY', currentData.professionalProfile, 'professionalProfile')}
      {renderEditableSection('METODY SPAWANIA', currentData.weldingMethods, 'weldingMethods')}
      {renderEditableSection('DOŚWIADCZENIE ZAWODOWE', currentData.professionalExperience, 'professionalExperience')}
      {renderEditableSection('CERTYFIKATY I UPRAWNIENIA', currentData.certificates, 'certificates')}
      {renderEditableSection('UMIEJĘTNOŚCI TECHNICZNE', currentData.technicalSkills, 'technicalSkills')}
      {renderEditableSection('INFORMACJE DODATKOWE', currentData.additionalInfo, 'additionalInfo')}
      {renderEditableSection('KIERUNEK ROZWOJU', currentData.developmentDirection, 'developmentDirection')}
    </div>
  );
};

export default CVPreview;