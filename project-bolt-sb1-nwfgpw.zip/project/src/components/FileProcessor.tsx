import React, { useEffect, useState } from 'react';
import { createWorker } from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist';
import { extractCVData } from '../services/openai';
import type { WelderCV } from '../types/cv';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface FileProcessorProps {
  file: File;
  onProcessing: (status: boolean) => void;
  onProcessed: (data: WelderCV) => void;
  onError: (error: string) => void;
}

const FileProcessor: React.FC<FileProcessorProps> = ({
  file,
  onProcessing,
  onProcessed,
  onError
}) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    processFile();
  }, [file]);

  const processFile = async () => {
    try {
      onProcessing(true);
      setProgress(10);
      let text = '';

      switch (file.type) {
        case 'application/pdf':
          text = await processPDF(file);
          break;
        case 'image/jpeg':
        case 'image/png':
          text = await processImage(file);
          break;
        case 'application/msword':
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          throw new Error('Przetwarzanie plików DOC/DOCX nie jest jeszcze obsługiwane');
        default:
          throw new Error('Nieobsługiwany format pliku');
      }

      if (!text.trim()) {
        throw new Error('Nie udało się wyodrębnić tekstu z pliku');
      }

      setProgress(50);
      const cvData = await extractCVData(text);
      setProgress(100);
      onProcessed(cvData);
    } catch (error) {
      console.error('Processing error:', error);
      onError(error instanceof Error ? error.message : 'Wystąpił nieznany błąd');
    } finally {
      onProcessing(false);
      setProgress(0);
    }
  };

  const processImage = async (imageFile: File): Promise<string> => {
    const worker = await createWorker('pol');
    try {
      setProgress(30);
      const { data: { text } } = await worker.recognize(imageFile);
      setProgress(40);
      return text;
    } finally {
      await worker.terminate();
    }
  };

  const processPDF = async (pdfFile: File): Promise<string> => {
    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        setProgress(10 + Math.floor((i / pdf.numPages) * 30));
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        fullText += pageText + '\n';
      }

      return fullText;
    } catch (error) {
      console.error('PDF processing error:', error);
      throw new Error('Błąd przetwarzania PDF. Upewnij się, że plik nie jest zabezpieczony.');
    }
  };

  return (
    <div className="fixed bottom-4 right-4 bg-white p-4 rounded-lg shadow-lg z-50">
      {progress > 0 && (
        <div className="flex items-center gap-4">
          <div className="w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-sm text-gray-600">
            {progress < 50 ? 'Odczytywanie tekstu...' : 'Analiza CV...'}
          </span>
        </div>
      )}
    </div>
  );
};

export default FileProcessor;