import html2pdf from 'html2pdf.js';
import type { WelderCV } from '../types/cv';

export async function generatePDF(data: WelderCV, photo: string | null): Promise<void> {
  try {
    const container = document.createElement('div');
    container.className = 'cv-container';
    container.style.cssText = `
      padding: 20mm;
      font-family: Arial, sans-serif;
      font-size: 11pt;
      line-height: 1.3;
    `;

    container.innerHTML = `
      <div class="page">
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
          <h1 style="font-size: 20px; font-weight: bold; margin: 0;">CV SPAWACZA</h1>
          ${photo ? `<img src="${photo}" alt="Zdjęcie" style="width: 35mm; height: 45mm; object-fit: cover;">` : ''}
        </div>

        <div style="margin-bottom: 15px;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">DANE OSOBOWE</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <p style="margin: 4px 0;">IMIĘ I NAZWISKO: ${data.personalData.fullName}</p>
            <p style="margin: 4px 0;">TEL: ${data.personalData.phone}</p>
            <p style="margin: 4px 0;">EMAIL: ${data.personalData.email}</p>
          </div>
        </div>

        <div style="margin-bottom: 15px;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">PROFIL ZAWODOWY</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <p style="margin: 0;">${data.professionalProfile}</p>
          </div>
        </div>

        <div style="margin-bottom: 15px;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">METODY SPAWANIA</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
              ${data.weldingMethods.map(method => `
                <div style="text-align: center;">
                  <div style="width: 80px; height: 80px; border: 2px solid black; border-radius: 50%; margin: 0 auto 8px; display: flex; align-items: center; justify-content: center; padding: 8px;">
                    <span style="font-family: monospace; font-size: 12px; line-height: 1.2;">${method.method}</span>
                  </div>
                  <p style="font-family: monospace; font-size: 11px; margin: 0;">${method.experience}</p>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <div style="margin-bottom: 15px;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">DOŚWIADCZENIE ZAWODOWE</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            ${data.professionalExperience.map(exp => `
              <div style="margin-bottom: 8px; break-inside: avoid;">
                <p style="font-weight: bold; margin: 0 0 4px 0;">${exp.period}</p>
                <ul style="margin: 0; padding-left: 20px;">
                  ${exp.details.map(detail => `<li style="margin-bottom: 2px;">${detail}</li>`).join('')}
                </ul>
              </div>
            `).join('')}
          </div>
        </div>

        <div style="margin-bottom: 15px; break-before: avoid;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">CERTYFIKATY I UPRAWNIENIA</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <div style="margin-bottom: 8px; break-inside: avoid;">
              <h3 style="font-weight: bold; margin: 0 0 4px 0;">SPAWALNICZE:</h3>
              <ul style="margin: 0; padding-left: 20px;">
                ${data.certificates.welding.map(cert => `<li style="margin-bottom: 2px;">${cert}</li>`).join('')}
              </ul>
            </div>
            <div style="margin-bottom: 8px; break-inside: avoid;">
              <h3 style="font-weight: bold; margin: 0 0 4px 0;">BHP:</h3>
              <ul style="margin: 0; padding-left: 20px;">
                ${data.certificates.healthAndSafety.map(cert => `<li style="margin-bottom: 2px;">${cert}</li>`).join('')}
              </ul>
            </div>
            <div style="break-inside: avoid;">
              <h3 style="font-weight: bold; margin: 0 0 4px 0;">TRANSPORT BLISKI:</h3>
              <ul style="margin: 0; padding-left: 20px;">
                ${data.certificates.transport.map(cert => `<li style="margin-bottom: 2px;">${cert}</li>`).join('')}
              </ul>
            </div>
          </div>
        </div>

        <div style="margin-bottom: 15px; break-before: avoid;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">UMIEJĘTNOŚCI TECHNICZNE</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <ul style="margin: 0; padding-left: 20px;">
              ${data.technicalSkills.map(skill => `<li style="margin-bottom: 2px;">${skill}</li>`).join('')}
            </ul>
          </div>
        </div>

        <div style="margin-bottom: 15px; break-before: avoid;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">INFORMACJE DODATKOWE</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <p style="margin: 4px 0;">MOBILNOŚĆ: ${data.additionalInfo.mobility}</p>
            <p style="margin: 4px 0;">ROTACJA: ${data.additionalInfo.rotation}</p>
            <p style="margin: 4px 0;">FORMA ZATRUDNIENIA: ${data.additionalInfo.employmentForm}</p>
            <p style="margin: 4px 0;">WŁASNY SPRZĘT: ${data.additionalInfo.ownEquipment}</p>
          </div>
        </div>

        <div style="break-before: avoid;">
          <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 8px;">KIERUNEK ROZWOJU</h2>
          <div style="border: 1px solid #ccc; padding: 8px;">
            <p style="margin: 0;">${data.developmentDirection}</p>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(container);

    const opt = {
      margin: [15, 15, 15, 15],
      filename: `CV_${data.personalData.fullName.replace(/\s+/g, '_')}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { 
        scale: 2,
        letterRendering: true,
        useCORS: true,
        logging: false,
        scrollY: -window.scrollY
      },
      jsPDF: { 
        unit: 'mm', 
        format: 'a4', 
        orientation: 'portrait',
        compress: true
      },
      pagebreak: { 
        mode: ['avoid-all', 'css', 'legacy'],
        before: '.page-break',
        avoid: ['h2', 'h3', '.avoid-break']
      }
    };

    await html2pdf().set(opt).from(container).save();
    document.body.removeChild(container);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Wystąpił błąd podczas generowania PDF. Spróbuj ponownie.');
  }
}