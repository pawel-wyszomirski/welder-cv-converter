import OpenAI from 'openai';
import type { WelderCV } from '../types/cv';

const getOpenAIInstance = () => {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('OpenAI API key is not configured');
  }
  
  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true
  });
};

// ... rest of the code remains the same ...

export async function extractCVData(text: string): Promise<WelderCV> {
  try {
    const openai = getOpenAIInstance();
    
    // ... rest of the function remains the same ...
    
  } catch (error) {
    console.error('OpenAI API error:', error);
    if (error instanceof Error && error.message === 'OpenAI API key is not configured') {
      throw new Error('Błąd konfiguracji API. Skontaktuj się z administratorem.');
    }
    throw new Error('Wystąpił błąd podczas przetwarzania CV');
  }
}